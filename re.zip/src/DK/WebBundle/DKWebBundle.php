<?php

namespace DK\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DKWebBundle extends Bundle
{
}
