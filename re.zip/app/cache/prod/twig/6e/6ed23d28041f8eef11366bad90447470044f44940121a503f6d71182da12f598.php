<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_92240ecbdbcfb216f52f58c3456c21b03f146b0b982cc1ec33bc8c4d6e27d4bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
